<?php
$fields_array['ReportParameterLink'] = array (
	'column_fields' => array(
		"id"
		,"template_id"
		,"parameter_id"
		,"name"
		,"default_value"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
        'list_fields' =>  array(
		"id"
		,"template_id"
		,"parameter_id"
		,"name"
		,"default_value"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
    	'required_fields' =>  array('name'=>1),
);
?>
