<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ZuckerReportDisplayDashlet'] = array('LBL_TITLE'            => 'ZuckerReports Dashlet',
                                         'LBL_DESCRIPTION'      => 'Zeigt den Live-Inhalt eines Berichts in einem Dashlet an',
										 'LBL_NOTITLE' => ' Bitte einen Bericht aus&auml;hlen',
                                         'LBL_CONFIGURE_RUNNABLE' => 'Ausf&uuml;hrbarer Bericht'

);
?> 
