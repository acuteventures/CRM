<?php
$fields_array['ReportModuleLink'] = array (
	'column_fields' => array(
		"id"
		,"parameterlink_id"
		,"module_name"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
        'list_fields' =>  array(
		"id"
		,"parameterlink_id"
		,"module_name"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
    	'required_fields' =>  array('name'=>1),
);
?>
