<?php
$mod_strings = return_module_language("es_es", "ZuckerReports");
$mod_list_strings = return_mod_list_strings_language("es_es", "ZuckerReports");
?>
