<?php
$mod_strings = return_module_language("en_us", "ZuckerReports");
$mod_list_strings = return_mod_list_strings_language("en_us", "ZuckerReports");
?>
