<?php
$mod_strings = return_module_language("fr_FR", "ZuckerReports");
$mod_list_strings = return_mod_list_strings_language("fr_FR", "ZuckerReports");
?>
