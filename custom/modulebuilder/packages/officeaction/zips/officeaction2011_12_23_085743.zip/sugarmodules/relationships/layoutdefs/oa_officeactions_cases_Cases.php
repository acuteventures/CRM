<?php
 // created: 2011-12-23 08:57:42
$layout_defs["Cases"]["subpanel_setup"]['oa_officeactions_cases'] = array (
  'order' => 100,
  'module' => 'oa_officeactions',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OA_OFFICEACTIONS_CASES_FROM_OA_OFFICEACTIONS_TITLE',
  'get_subpanel_data' => 'oa_officeactions_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
