<?php
// created: 2011-12-21 07:41:25
$dictionary["oa_officeactions"]["fields"]["oa_officeactions_notes"] = array (
  'name' => 'oa_officeactions_notes',
  'type' => 'link',
  'relationship' => 'oa_officeactions_notes',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_OA_OFFICEACTIONS_NOTES_FROM_NOTES_TITLE',
);
