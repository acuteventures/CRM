<?php
// created: 2011-12-21 07:41:25
$dictionary["Note"]["fields"]["oa_officeactions_notes"] = array (
  'name' => 'oa_officeactions_notes',
  'type' => 'link',
  'relationship' => 'oa_officeactions_notes',
  'source' => 'non-db',
  'vname' => 'LBL_OA_OFFICEACTIONS_NOTES_FROM_OA_OFFICEACTIONS_TITLE',
  'id_name' => 'oa_officeactions_notesoa_officeactions_ida',
);
$dictionary["Note"]["fields"]["oa_officeactions_notes_name"] = array (
  'name' => 'oa_officeactions_notes_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_OA_OFFICEACTIONS_NOTES_FROM_OA_OFFICEACTIONS_TITLE',
  'save' => true,
  'id_name' => 'oa_officeactions_notesoa_officeactions_ida',
  'link' => 'oa_officeactions_notes',
  'table' => 'oa_officeactions',
  'module' => 'oa_officeactions',
  'rname' => 'name',
);
$dictionary["Note"]["fields"]["oa_officeactions_notesoa_officeactions_ida"] = array (
  'name' => 'oa_officeactions_notesoa_officeactions_ida',
  'type' => 'link',
  'relationship' => 'oa_officeactions_notes',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_OA_OFFICEACTIONS_NOTES_FROM_NOTES_TITLE',
);
